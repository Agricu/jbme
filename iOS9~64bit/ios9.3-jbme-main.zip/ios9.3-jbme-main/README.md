# ios9.3.3-jailbreak-website

A copy from https://jbme.qwertyoruiop.com/

download according to https://www.reddit.com/r/jailbreak/comments/5j1k2q/help_change_my_hosts_file_and_cant_rejailbreak_my/

# files

https://jbme.qwertyoruiop.com/index.html

https://jbme.qwertyoruiop.com/exec

https://jbme.qwertyoruiop.com/loader
