## jailbreak for iOS9.1~9.3.4(32bit only)


官方地址：https://jailbreak.me


搬运：https://cydia.agricu.cn


官方打包下载路径:

wget https://jailbreak.me/index.html
wget https://jailbreak.me/stage1.bin
wget https://jailbreak.me/payload/offsets.json
wget https://jailbreak.me/payload/launchctl
wget https://jailbreak.me/payload/Cydia.tar
wget https://jailbreak.me/payload/tar